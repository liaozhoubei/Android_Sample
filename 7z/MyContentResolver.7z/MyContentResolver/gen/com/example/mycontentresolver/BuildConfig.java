/** Automatically generated file. DO NOT MODIFY */
package com.example.mycontentresolver;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}