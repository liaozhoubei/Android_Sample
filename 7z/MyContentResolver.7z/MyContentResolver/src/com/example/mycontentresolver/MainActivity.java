package com.example.mycontentresolver;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		Button addData = (Button) findViewById(R.id.add_data);
		Button queryData = (Button) findViewById(R.id.query_data);
		Button updateData = (Button) findViewById(R.id.update_data);
		Button deleteData = (Button) findViewById(R.id.delete_data);
		
		addData.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Uri url = Uri.parse("content://com.example.databasecontentprovider.provider/insert");
				ContentValues values = new ContentValues();
				values.put("bookname", "A Clash of Kings");
				values.put("author", "George Martin");
				values.put("pages", 1040);
				values.put("price", 55.55);
				ContentResolver contentResolver = getContentResolver();
				Uri insert = contentResolver.insert(url, values);
				System.out.println(insert);
			}
		});
		
		queryData.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Uri url = Uri.parse("content://com.example.databasecontentprovider.provider/query");	
				ContentResolver contentResolver = getContentResolver();
				Cursor query = contentResolver.query(url, null, null, null, null);
				if (query != null) {
					while (query.moveToNext()){
						String autor = query.getString(1);
						String prices = query.getString(2);
						String pages = query.getString(3);
						String bookname = query.getString(4);
						System.out.println(autor + "   " + prices + "   " + pages +"   " + bookname);
					}
				}
			}
		});
		
		updateData.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Uri url = Uri.parse("content://com.example.databasecontentprovider.provider/update");
				ContentValues values = new ContentValues();
				values.put("bookname", "A Storm of Swords");
				values.put("pages", 1216);
				values.put("price", 24.05);	
				ContentResolver contentResolver = getContentResolver();
				// 将所有内容的书名、页数、价格更新
				int update = contentResolver.update(url, values, null, null);
				System.out.println("更新了" + update + "条数据");
			}
		});
		
		deleteData.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Uri url = Uri.parse("content://com.example.databasecontentprovider.provider/delete");
				ContentResolver contentResolver = getContentResolver();
				// 删除名为《A Storm of Swords》的书籍
				int delete = contentResolver.delete(url, "bookname = ?", new String[]{"A Storm of Swords"});
				System.out.println("删除了" + delete + "条数据");
			}
		});
	}

}
